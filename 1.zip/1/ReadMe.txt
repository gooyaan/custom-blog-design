Template Name:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Launch (HTML5 crowdfunding bootstrap template)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

Template Version:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

Release Date:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
15/04/2016
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

Author:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Justin Audain - Audain Designs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

Contact:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
web:http://themes.audaindesigns.com
email:info@audaindesigns.com
twitter:@audaindesigns
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	

License:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This template is intended to be free to use under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	