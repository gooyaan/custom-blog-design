const GET_LOG = false;
var ACTION_GET_USER = "getUser";
var ACTION_GET_POST_CONTENT = "getPostWithHtmlContent";
var API_URL = "https://gooyaan.ir/developer/api/index.php";
var API_KEY = "549366680572-jy4-kOuUkr";

function GYN_get_user_posts(callback) {
    G_send_request(API_URL, {
        'action': ACTION_GET_USER,
        'api_key': API_KEY,
    }, callback);
}

function GYN_get_post_data(postId, callback) {
    G_send_request(API_URL, {
        'action': ACTION_GET_POST_CONTENT,
        'api_key': API_KEY,
        'post_id': postId
    }, callback);
}

function G_send_request(url, data, callback, method = "POST") {
    var response;
    getLog("Raw URL: " + url);
    getLog("Raw Request: " + JSON.stringify(data));
    const Http = new XMLHttpRequest();
    Http.open(method, url);
    Http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    Http.send("request=" + JSON.stringify(data));
    Http.onreadystatechange = function (){
        if (Http.readyState === 4 && Http.status === 200)
            callback(JSON.parse(Http.responseText));
    }
}


function getLog(message) {
    if (GET_LOG) {
        console.log(message);
    }
}