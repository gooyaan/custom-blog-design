# Launch
Launch is a responsive html5 bootstrap free crowdfunding template, which is focused on promoting a websites funding campaign.

With Launch You'll be able to take full control of your crowdfunding campaign and control the process from start to finish, this is without having to rely on third party services which require fees which are usually deducted from your total campaign.

# Author

This template is made by Justin at [Audain Designs.](http://themes.audaindesigns.com)

#Licensing

All non commercial themes and templates found on Audain Designs are 100% free and covered under the [Creative Commons Attribution 3.0 License (CC BY 3.0)](http://creativecommons.org/licenses/by/3.0/)

**Other Options**

If you’d like to use this bootstrap template without the attribution link, you can choose to purchase the commercial license: [Purchase Launch](http://bit.ly/2kAgb8K)

#Features

- Landing Page Template
- Easy to Customize
- Bootstrap
- Google Fonts
- FontAwesome Icons

#Credits

All Images are for demo purposes only and not included in the template, sources are included & all other sources and credits are included in the documentation.

- UI Faces
- Google Web Fonts
- FontAwesome Icon
- jQuery
- Bootstrap

---

10 Feb 17
- Readme Updated
